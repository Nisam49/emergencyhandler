package com.example.emergencyhandler;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;
import com.google.android.gms.drive.DriveFile;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import org.json.JSONException;
import org.json.JSONObject;

public class deleteaccjson extends AsyncTask<String, Void, String> {
    private Context context;
    String usernamefc;

    public deleteaccjson(Context context) {
        this.context = context;
    }

    protected void onPreExecute() {
    }

    protected String doInBackground(String... arg0) {
        this.usernamefc = arg0[0];
        try {
            return new BufferedReader(new InputStreamReader(((HttpURLConnection) new URL("https://codersclub.000webhostapp.com/deleteacc.php" + ("?uname=" + URLEncoder.encode(this.usernamefc, "UTF-8"))).openConnection()).getInputStream())).readLine();
        } catch (Exception e) {
            return new String("Exception: " + e.getMessage());
        }
    }

    protected void onPostExecute(String result) {
        String jsonStr = result;
        if (jsonStr != null) {
            try {
                String query_result = new JSONObject(jsonStr).getString("query_result");
                if (query_result.equals("SUCCESS")) {
                    Toast.makeText(this.context, "Successfully Removed...", 0).show();
                    new DatabaseTest(this.context).truncateTable();
                    Intent i = new Intent(this.context, LoginActivity.class);
                    i.addFlags(DriveFile.MODE_READ_ONLY);
                    this.context.startActivity(i);
                    return;
                } else if (query_result.equals("FAILURE")) {
                    Toast.makeText(this.context, "Something Wrong...Try Again..", 0).show();
                    return;
                } else if (query_result.equals("ERROR")) {
                    Toast.makeText(this.context, "Couldn't connect to Remote database...Try Again", 0).show();
                    return;
                } else {
                    return;
                }
            } catch (JSONException e) {
                e.printStackTrace();
                Toast.makeText(this.context, "Bad Internet Connection...Try Again...", 0).show();
                return;
            }
        }
        Toast.makeText(this.context, "Bad Internet Connection...Try Again...", 0).show();
    }
}
