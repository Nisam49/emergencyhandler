package com.example.emergencyhandler;

import android.app.AlertDialog.Builder;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.NavigationView.OnNavigationItemSelectedListener;
import android.support.design.widget.Snackbar;
import android.support.v4.app.NotificationCompat;
import android.support.v4.internal.view.SupportMenu;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import coderzclub.doordie.Gps_and_Network_Location.GPSService;

public class DrawerActivity extends AppCompatActivity implements OnNavigationItemSelectedListener {
    public CoordinatorLayout coordinatorLayout = null;
    DatabaseTest db;
    TextView email;
    GPSService gp;
    TextView name;
    SharedPreferences sharedpreferences;

    /* renamed from: coderzclub.doordie.DrawerActivity$1 */
    class C02531 implements OnClickListener {
        C02531() {
        }

        public void onClick(View v) {
            if (!DrawerActivity.this.sharedpreferences.contains("ButtonE")) {
                return;
            }
            if (!DrawerActivity.this.sharedpreferences.getString("ButtonE", null).equals("Enable")) {
                Toast.makeText(DrawerActivity.this, "Button Disabled...Enable it in DOD Settings..", 0).show();
            } else if (DrawerActivity.this.sharedpreferences.getString("MessageO", null).equals("Enable")) {
                DrawerActivity.this.startActivity(new Intent(DrawerActivity.this.getApplicationContext(), DODHelp.class));
            } else {
                DrawerActivity.this.startActivity(new Intent(DrawerActivity.this.getApplicationContext(), DODfinal.class));
            }
        }
    }

    /* renamed from: coderzclub.doordie.DrawerActivity$2 */
    class C02542 implements OnClickListener {
        C02542() {
        }

        public void onClick(View v) {
            if (!DrawerActivity.this.sharedpreferences.contains("MessageR")) {
                return;
            }
            if (DrawerActivity.this.sharedpreferences.getString("MessageR", null).equals("Enable")) {
                DrawerActivity.this.startActivity(new Intent(DrawerActivity.this.getApplicationContext(), ReportHelp.class));
                return;
            }
            DrawerActivity.this.startActivity(new Intent(DrawerActivity.this.getApplicationContext(), Report.class));
        }
    }

    /* renamed from: coderzclub.doordie.DrawerActivity$3 */
    class C02553 implements OnClickListener {
        C02553() {
        }

        public void onClick(View v) {
            DrawerActivity.this.startActivity(new Intent(DrawerActivity.this.getApplicationContext(), Messaging.class));
        }
    }

    /* renamed from: coderzclub.doordie.DrawerActivity$4 */
    class C02564 implements OnClickListener {
        C02564() {
        }

        public void onClick(View v) {
            if (!DrawerActivity.this.sharedpreferences.contains("MessageB")) {
                Toast.makeText(DrawerActivity.this, "Failed..", 0).show();
            } else if (DrawerActivity.this.sharedpreferences.getString("MessageB", null).equals("Enable")) {
                DrawerActivity.this.startActivity(new Intent(DrawerActivity.this.getApplicationContext(), callconfirm.class));
            } else {
                DrawerActivity.this.startActivity(new Intent(DrawerActivity.this.getApplicationContext(), EmergencyNumbers.class));
            }
        }
    }

    /* renamed from: coderzclub.doordie.DrawerActivity$5 */
    class C02575 implements OnClickListener {
        C02575() {
        }

        public void onClick(View v) {
            DrawerActivity.this.startActivity(new Intent(DrawerActivity.this.getApplicationContext(), Precautions.class));
        }
    }

    /* renamed from: coderzclub.doordie.DrawerActivity$6 */
    class C02586 implements OnClickListener {
        C02586() {
        }

        public void onClick(View v) {
            DrawerActivity.this.startActivity(new Intent(DrawerActivity.this.getApplicationContext(), Escape_Plans.class));
        }
    }

    /* renamed from: coderzclub.doordie.DrawerActivity$7 */
    class C02597 implements OnClickListener {
        C02597() {
        }

        public void onClick(View v) {
            DrawerActivity.this.startActivity(new Intent(DrawerActivity.this.getApplicationContext(), Remedies.class));
        }
    }

    /* renamed from: coderzclub.doordie.DrawerActivity$8 */
    class C02608 implements OnClickListener {
        C02608() {
        }

        public void onClick(View v) {
            DrawerActivity.this.startActivity(new Intent(DrawerActivity.this.getApplicationContext(), FirstAid.class));
        }
    }

    /* renamed from: coderzclub.doordie.DrawerActivity$9 */
    class C02639 implements OnClickListener {

        /* renamed from: coderzclub.doordie.DrawerActivity$9$1 */
        class C02611 implements DialogInterface.OnClickListener {
            C02611() {
            }

            public void onClick(DialogInterface dialog, int id) {
                DrawerActivity.this.db.truncateTable();
                DrawerActivity.this.finish();
                System.exit(0);
            }
        }

        /* renamed from: coderzclub.doordie.DrawerActivity$9$2 */
        class C02622 implements DialogInterface.OnClickListener {
            C02622() {
            }

            public void onClick(DialogInterface dialog, int id) {
                DrawerActivity.this.finish();
                System.exit(0);
            }
        }

        C02639() {
        }

        public void onClick(View view) {
            Builder alertDialogBuilder = new Builder(DrawerActivity.this);
            alertDialogBuilder.setTitle("DOD");
            alertDialogBuilder.setMessage("Choose an Exit Method...").setCancelable(false).setPositiveButton("EXIT WITHOUT LOGOUT", new C02622()).setNegativeButton("EXIT AND LOGOUT", new C02611());
            alertDialogBuilder.create().show();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_drawer);
        this.gp = new GPSService(getApplicationContext());
        this.sharedpreferences = getSharedPreferences("mypref", 0);
        startService(new Intent(getApplicationContext(), DODEmergency.class));
        NotificationManager mgr1u = (NotificationManager) getSystemService("notification");
        NotificationCompat.Builder note2u = new NotificationCompat.Builder(this);
        note2u.setContentTitle("DOD Emergency Enabled");
        note2u.setContentText("Configure it in DOD Settings");
        note2u.setTicker("Emergency Service has Enabled.....");
        note2u.setAutoCancel(true);
        note2u.setOngoing(true);
        note2u.setDefaults(1);
        note2u.setSmallIcon(C0274R.drawable.ic_stat_name);
        note2u.setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), 0));
        mgr1u.notify(101, note2u.build());
        this.db = new DatabaseTest(getApplicationContext());
        Toolbar toolbar = (Toolbar) findViewById(C0274R.id.toolbar);
        setSupportActionBar(toolbar);
        RelativeLayout r = (RelativeLayout) findViewById(C0274R.id.relativeLayout6);
        RelativeLayout r2 = (RelativeLayout) findViewById(C0274R.id.relativeLayout7);
        RelativeLayout r3 = (RelativeLayout) findViewById(C0274R.id.relativeLayout8);
        RelativeLayout r4 = (RelativeLayout) findViewById(C0274R.id.relativeLayout9);
        RelativeLayout r6 = (RelativeLayout) findViewById(C0274R.id.relativeLayout11);
        RelativeLayout r7 = (RelativeLayout) findViewById(C0274R.id.relativeLayout12);
        RelativeLayout r8 = (RelativeLayout) findViewById(C0274R.id.relativeLayout13);
        RelativeLayout r9 = (RelativeLayout) findViewById(C0274R.id.relativeLayout14);
        ((TextView) findViewById(C0274R.id.textView16)).setText("Hai " + this.db.getName().toString());
        r.setOnClickListener(new C02531());
        r2.setOnClickListener(new C02542());
        r3.setOnClickListener(new C02553());
        r4.setOnClickListener(new C02564());
        r6.setOnClickListener(new C02575());
        r7.setOnClickListener(new C02586());
        r8.setOnClickListener(new C02597());
        r9.setOnClickListener(new C02608());
        ((FloatingActionButton) findViewById(C0274R.id.fab)).setOnClickListener(new C02639());
        DrawerLayout drawer = (DrawerLayout) findViewById(C0274R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, C0274R.string.navigation_drawer_open, C0274R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = (NavigationView) findViewById(C0274R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View header = navigationView.getHeaderView(0);
        this.name = (TextView) header.findViewById(C0274R.id.NameField);
        this.email = (TextView) header.findViewById(C0274R.id.EmailField);
        this.name.setText(this.db.getName().toString());
        this.email.setText(this.db.getEmail().toString());
    }

    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(C0274R.id.drawer_layout);
        if (drawer.isDrawerOpen(8388611)) {
            drawer.closeDrawer(8388611);
            return;
        }
        super.onBackPressed();
        finish();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(C0274R.menu.drawer, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() != C0274R.id.action_settings) {
            return super.onOptionsItemSelected(item);
        }
        startActivity(new Intent(getApplicationContext(), Setting.class));
        return true;
    }

    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == C0274R.id.nav_firstaid) {
            startActivity(new Intent(getApplicationContext(), FirstAid.class));
        } else if (id == C0274R.id.nav_about) {
            startActivity(new Intent(getApplicationContext(), About.class));
        } else if (id == C0274R.id.nav_remedies) {
            startActivity(new Intent(getApplicationContext(), Remedies.class));
        } else if (id == C0274R.id.nav_logout) {
            this.db.truncateTable();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        } else if (id == C0274R.id.nav_dod) {
            startActivity(new Intent(getApplicationContext(), DODfinal.class));
        } else if (id == C0274R.id.nav_precations) {
            startActivity(new Intent(getApplicationContext(), Precautions.class));
        } else if (id == C0274R.id.nav_message) {
            startActivity(new Intent(getApplicationContext(), Messaging.class));
        } else if (id == C0274R.id.nav_emergency) {
            if (!this.sharedpreferences.contains("MessageB")) {
                Toast.makeText(this, "Failed..", 0).show();
            } else if (this.sharedpreferences.getString("MessageB", null).equals("Enable")) {
                startActivity(new Intent(getApplicationContext(), callconfirm.class));
            } else {
                startActivity(new Intent(getApplicationContext(), EmergencyNumbers.class));
            }
        } else if (id == C0274R.id.nav_escapeplans) {
            Snackbar snackbar;
            if (NetworkUtil.getConnectivityStatusString(this)) {
                snackbar = Snackbar.make(this.coordinatorLayout, (CharSequence) "Connected to Internet!", 0);
                ((TextView) snackbar.getView().findViewById(C0274R.id.snackbar_text)).setTextColor(-16711936);
                snackbar.show();
                startActivity(new Intent(getApplicationContext(), Escape_Plans.class));
            } else {
                snackbar = Snackbar.make(this.coordinatorLayout, (CharSequence) "No Internet connection!", 0);
                ((TextView) snackbar.getView().findViewById(C0274R.id.snackbar_text)).setTextColor(SupportMenu.CATEGORY_MASK);
                snackbar.show();
            }
        } else if (id == C0274R.id.nav_conditions) {
            startActivity(new Intent(getApplicationContext(), Terms.class));
        } else if (id == C0274R.id.nav_settings) {
            startActivity(new Intent(getApplicationContext(), Setting.class));
        } else if (id == C0274R.id.nav_report && this.sharedpreferences.contains("MessageR")) {
            if (this.sharedpreferences.getString("MessageR", null).equals("Enable")) {
                startActivity(new Intent(getApplicationContext(), ReportHelp.class));
            } else {
                startActivity(new Intent(getApplicationContext(), Report.class));
            }
        }
        ((DrawerLayout) findViewById(C0274R.id.drawer_layout)).closeDrawer(8388611);
        return true;
    }
}
