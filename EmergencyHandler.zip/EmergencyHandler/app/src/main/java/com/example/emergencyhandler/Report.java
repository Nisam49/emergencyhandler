package com.example.emergencyhandler;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.internal.view.SupportMenu;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Report extends AppCompatActivity implements OnItemSelectedListener {
    /* renamed from: b */
    Button f45b;
    /* renamed from: d */
    Date f46d;
    DatabaseTest db;
    EditText e1;
    EditText e2;
    EditText e3;
    EditText e4;
    EditText e5;
    EditText e6;
    EditText e7;
    int flag = 0;
    /* renamed from: i */
    int f47i = 0;
    String[] op = new String[]{"Type Of Problem", "Accident", "Disaster", "Attacks/Rapes", "Crime"};
    String selected = "";
    Spinner sp;
    SimpleDateFormat sp1;
    SimpleDateFormat sp2;

    /* renamed from: coderzclub.doordie.Report$1 */
    class C02781 implements OnClickListener {
        C02781() {
        }

        public void onClick(View v) {
            if (Report.this.f47i == 0) {
                Report report = Report.this;
                report.f47i++;
                Report.this.f45b.setBackgroundColor(SupportMenu.CATEGORY_MASK);
                Report.this.f45b.setTextColor(-1);
                Report.this.startActivity(new Intent(Report.this.getApplicationContext(), ReportAgreement.class));
                return;
            }
            Toast.makeText(Report.this, "Reporting...", 1).show();
            new reportjson(Report.this.getApplicationContext()).execute(new String[]{Report.this.e1.getText().toString(), Report.this.e7.getText().toString(), Report.this.e2.getText().toString(), Report.this.e3.getText().toString(), Report.this.e4.getText().toString(), Report.this.e5.getText().toString(), Report.this.e6.getText().toString(), Report.this.selected, Report.this.db.getName(), Report.this.db.getPhone()});
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_report);
        this.f46d = new Date();
        this.sp1 = new SimpleDateFormat("yyyy/MM/dd");
        this.sp2 = new SimpleDateFormat("hh:mm a");
        this.e1 = (EditText) findViewById(C0274R.id.editText7);
        this.e2 = (EditText) findViewById(C0274R.id.editText8);
        this.e3 = (EditText) findViewById(C0274R.id.editText9);
        this.e4 = (EditText) findViewById(C0274R.id.editText10);
        this.e5 = (EditText) findViewById(C0274R.id.editText11);
        this.e7 = (EditText) findViewById(C0274R.id.editText13);
        this.f45b = (Button) findViewById(C0274R.id.button6);
        this.e6 = (EditText) findViewById(C0274R.id.editText12);
        this.db = new DatabaseTest(getApplicationContext());
        this.sp = (Spinner) findViewById(C0274R.id.spinner);
        this.sp.setAdapter(new ArrayAdapter(getApplicationContext(), 17367048, this.op));
        this.sp.setOnItemSelectedListener(this);
        this.f45b.setOnClickListener(new C02781());
    }

    public void onItemSelected(AdapterView<?> adapterView, View arg1, int position, long id) {
        if (position == 0) {
            this.flag = 0;
            this.e1.setEnabled(false);
            this.e2.setEnabled(false);
            this.e3.setEnabled(false);
            this.e4.setEnabled(false);
            this.e5.setEnabled(false);
            this.e6.setEnabled(false);
            this.e7.setEnabled(false);
            this.f45b.setEnabled(false);
        } else {
            this.flag = 1;
        }
        if (position == 1) {
            this.e1.setEnabled(true);
            this.e2.setEnabled(true);
            this.e3.setEnabled(true);
            this.e4.setEnabled(true);
            this.e5.setEnabled(true);
            this.e6.setEnabled(true);
            this.e7.setEnabled(true);
            this.e1.setHint("Place Of Accident");
            this.e4.setText(this.sp2.format(this.f46d).toString());
            this.e5.setText(this.sp1.format(this.f46d).toString());
            this.f45b.setEnabled(true);
        } else if (position == 2) {
            this.e1.setEnabled(true);
            this.e2.setEnabled(true);
            this.e3.setEnabled(true);
            this.e7.setEnabled(true);
            this.e4.setEnabled(true);
            this.e5.setEnabled(true);
            this.e6.setEnabled(true);
            this.e1.setHint("Place Of Disaster");
            this.e4.setText(this.sp2.format(this.f46d).toString());
            this.e5.setText(this.sp1.format(this.f46d).toString());
            this.f45b.setEnabled(true);
        } else if (position == 3) {
            this.e1.setEnabled(true);
            this.e2.setEnabled(true);
            this.e3.setEnabled(true);
            this.e4.setEnabled(true);
            this.e7.setEnabled(true);
            this.e5.setEnabled(true);
            this.e6.setEnabled(true);
            this.e1.setHint("Place Of Incident");
            this.e4.setText(this.sp2.format(this.f46d).toString());
            this.e5.setText(this.sp1.format(this.f46d).toString());
            this.f45b.setEnabled(true);
        } else if (position == 4) {
            this.e1.setEnabled(true);
            this.e2.setEnabled(true);
            this.e3.setEnabled(true);
            this.e4.setEnabled(true);
            this.e7.setEnabled(true);
            this.e5.setEnabled(true);
            this.e6.setEnabled(true);
            this.e1.setHint("Place [Crime Happened]");
            this.e4.setText(this.sp2.format(this.f46d).toString());
            this.e5.setText(this.sp1.format(this.f46d).toString());
            this.f45b.setEnabled(true);
        }
        this.selected = this.op[position];
    }

    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    protected void onResume() {
        super.onResume();
        this.f45b.setBackgroundColor(-1);
        this.f45b.setTextColor(ViewCompat.MEASURED_STATE_MASK);
    }
}
