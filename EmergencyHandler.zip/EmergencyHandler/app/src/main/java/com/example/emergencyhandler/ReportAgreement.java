package com.example.emergencyhandler;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class ReportAgreement extends Activity {
    /* renamed from: b */
    Button f9b;
    Button b2;

    /* renamed from: coderzclub.doordie.ReportAgreement$1 */
    class C02791 implements OnClickListener {
        C02791() {
        }

        public void onClick(View v) {
            Toast.makeText(ReportAgreement.this, "Click Report Again to Confirm...", 0).show();
            ReportAgreement.this.finish();
        }
    }

    /* renamed from: coderzclub.doordie.ReportAgreement$2 */
    class C02802 implements OnClickListener {
        C02802() {
        }

        public void onClick(View v) {
            ReportAgreement.this.startActivity(new Intent(ReportAgreement.this, DrawerActivity.class));
            ReportAgreement.this.finish();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0274R.layout.activity_report_agreement);
        this.f9b = (Button) findViewById(C0274R.id.button8);
        this.b2 = (Button) findViewById(C0274R.id.button9);
        this.f9b.setOnClickListener(new C02791());
        this.b2.setOnClickListener(new C02802());
    }
}
