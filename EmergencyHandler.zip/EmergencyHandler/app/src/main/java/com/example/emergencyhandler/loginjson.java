package com.example.emergencyhandler;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.google.android.gms.drive.DriveFile;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import org.json.JSONException;
import org.json.JSONObject;

public class loginjson extends AsyncTask<String, Void, String> {
    private Context context;
    DatabaseTest db;
    /* renamed from: p */
    ProgressBar f11p;
    String password;
    String username;

    public loginjson(Context context) {
        this.context = context;
        this.db = new DatabaseTest(context);
    }

    protected void onPreExecute() {
    }

    protected String doInBackground(String... arg0) {
        this.username = arg0[0];
        this.password = arg0[1];
        try {
            HttpURLConnection con = (HttpURLConnection) new URL("https://codersclub.000webhostapp.com/login.php" + (("?username=" + URLEncoder.encode(this.username, "UTF-8")) + "&password=" + URLEncoder.encode(this.password, "UTF-8"))).openConnection();
            StringBuilder sb = new StringBuilder();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
            while (true) {
                String result = bufferedReader.readLine();
                if (result == null) {
                    return sb.toString().trim();
                }
                sb.append(result + "\n");
            }
        } catch (Exception e) {
            return new String("Exception: " + e.getMessage());
        }
    }

    protected void onPostExecute(String result) {
        String jsonStr = result;
        if (jsonStr != null) {
            try {
                String query_result = new JSONObject(jsonStr).getString("query_result");
                if (query_result.equals("SUCCESS")) {
                    Intent i = new Intent(this.context, LoadingAfterLogin.class);
                    i.putExtra("useusername", this.username);
                    i.putExtra("usepassword", this.password);
                    i.addFlags(DriveFile.MODE_READ_ONLY);
                    this.context.startActivity(i);
                    return;
                } else if (query_result.equals("FAILURE")) {
                    Toast.makeText(this.context, "Wrong Username or Password ....", 0).show();
                    return;
                } else if (query_result.equals("ERROR")) {
                    Toast.makeText(this.context, "Couldn't connect to Remote database...Try Again", 0).show();
                    return;
                } else {
                    return;
                }
            } catch (JSONException e) {
                e.printStackTrace();
                Toast.makeText(this.context, "Bad Internet Connection...Try Again...", 0).show();
                return;
            } catch (Exception e2) {
                e2.printStackTrace();
                return;
            }
        }
        Toast.makeText(this.context, "Bad Internet Connection...Try Again...", 0).show();
    }
}
