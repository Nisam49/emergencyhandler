package com.example.emergencyhandler;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class SmsConfirm extends AppCompatActivity {
    /* renamed from: b */
    Button f48b;
    Button b2;

    /* renamed from: coderzclub.doordie.SmsConfirm$1 */
    class C02821 implements OnClickListener {
        C02821() {
        }

        public void onClick(View v) {
            SmsConfirm.this.finish();
        }
    }

    /* renamed from: coderzclub.doordie.SmsConfirm$2 */
    class C02832 implements OnClickListener {
        C02832() {
        }

        public void onClick(View v) {
            SmsConfirm.this.finish();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_sms_confirm);
        this.f48b = (Button) findViewById(C0274R.id.button8);
        this.b2 = (Button) findViewById(C0274R.id.button10);
        this.f48b.setOnClickListener(new C02821());
        this.b2.setOnClickListener(new C02832());
    }
}
