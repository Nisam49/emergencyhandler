package com.example.emergencyhandler;

import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;

public class callconfirm extends AppCompatActivity {
    /* renamed from: r */
    RelativeLayout f49r;

    /* renamed from: coderzclub.doordie.callconfirm$1 */
    class C02861 implements OnClickListener {
        C02861() {
        }

        public void onClick(View v) {
            callconfirm.this.startActivity(new Intent(callconfirm.this.getApplicationContext(), EmergencyNumbers.class));
            callconfirm.this.finish();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_callconfirm);
        this.f49r = (RelativeLayout) findViewById(C0274R.id.relativeLayout20);
        Editor editor = getSharedPreferences("mypref", 0).edit();
        editor.putString("MessageB", "Disable");
        editor.commit();
        this.f49r.setOnClickListener(new C02861());
    }
}
