package com.example.emergencyhandler;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.telephony.SmsManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Messaging extends AppCompatActivity implements OnItemSelectedListener {
    String[] ac = new String[]{"Police Help", "Motor Vehicles Department Complaint"};
    /* renamed from: b */
    Button f41b;
    /* renamed from: e */
    EditText f42e;
    String num = "";
    Spinner sp;
    /* renamed from: t */
    TextView f43t;

    /* renamed from: coderzclub.doordie.Messaging$1 */
    class C02721 implements OnClickListener {

        /* renamed from: coderzclub.doordie.Messaging$1$1 */
        class C02701 extends BroadcastReceiver {
            C02701() {
            }

            public void onReceive(Context arg0, Intent arg1) {
                switch (getResultCode()) {
                    case -1:
                        Toast.makeText(Messaging.this.getApplicationContext(), "SMS Sent Successfully..", 0).show();
                        return;
                    case 1:
                        Toast.makeText(Messaging.this.getApplicationContext(), "You Don't have Sufficient Balance..", 0).show();
                        return;
                    case 2:
                        Toast.makeText(Messaging.this.getApplicationContext(), "You might be in Airplane Mode/Mobile Network is Off", 0).show();
                        return;
                    case 3:
                        Toast.makeText(Messaging.this.getApplicationContext(), "SMS Null PDU", 0).show();
                        return;
                    case 4:
                        Toast.makeText(Messaging.this.getApplicationContext(), "Network Error.No Service..", 0).show();
                        return;
                    default:
                        return;
                }
            }
        }

        /* renamed from: coderzclub.doordie.Messaging$1$2 */
        class C02712 extends BroadcastReceiver {
            C02712() {
            }

            public void onReceive(Context arg0, Intent arg1) {
                switch (getResultCode()) {
                    case -1:
                        Toast.makeText(Messaging.this.getApplicationContext(), "DOD SMS Delivered....", 0).show();
                        return;
                    case 0:
                        Toast.makeText(Messaging.this.getApplicationContext(), "DOD SMS Canceled....", 0).show();
                        return;
                    default:
                        return;
                }
            }
        }

        C02721() {
        }

        public void onClick(View v) {
            if (Messaging.this.f41b.getText().equals("CONFIRM SEND")) {
                Messaging.this.startActivity(new Intent(Messaging.this.getApplicationContext(), SmsConfirm.class));
                Messaging.this.f41b.setText("SEND SMS");
            } else if (Messaging.this.f41b.getText().equals("SEND SMS")) {
                try {
                    if (Messaging.this.f42e.getText().toString().length() >= 140) {
                        Toast.makeText(Messaging.this, "Message is too Large....", 0).show();
                    } else if (Messaging.this.f42e.getText().toString().isEmpty()) {
                        Toast.makeText(Messaging.this, "Message Empty...", 0).show();
                    } else {
                        Toast.makeText(Messaging.this, "SMS Sent.....", 0).show();
                        String SENT = "SMS_SENT";
                        String DELIVERED = "SMS_DELIVERED";
                        PendingIntent sentPI = PendingIntent.getBroadcast(Messaging.this, 0, new Intent(SENT), 0);
                        PendingIntent deliveredPI = PendingIntent.getBroadcast(Messaging.this, 0, new Intent(DELIVERED), 0);
                        Messaging.this.registerReceiver(new C02701(), new IntentFilter(SENT));
                        Messaging.this.registerReceiver(new C02712(), new IntentFilter(DELIVERED));
                        SmsManager.getDefault().sendTextMessage("9072968354", null, Messaging.this.f42e.getText().toString(), sentPI, deliveredPI);
                    }
                } catch (Exception e) {
                    Toast.makeText(Messaging.this, "Unable To Send SMS...Permission Denied for Sending Messages..Grant the SMS Permission in app settings", 0).show();
                }
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_messaging);
        this.sp = (Spinner) findViewById(C0274R.id.spinner2);
        this.f42e = (EditText) findViewById(C0274R.id.editText14);
        this.f41b = (Button) findViewById(C0274R.id.button9);
        this.f43t = (TextView) findViewById(C0274R.id.textView47);
        this.sp.setAdapter(new ArrayAdapter(getApplicationContext(), 17367048, this.ac));
        this.sp.setOnItemSelectedListener(this);
        this.f41b.setOnClickListener(new C02721());
    }

    public void onItemSelected(AdapterView<?> adapterView, View arg1, int position, long id) {
        if (position == 0) {
            this.f43t.setText(C0274R.string.appwidget_tdext);
            this.num = "9497900000";
        } else if (position == 1) {
            this.f43t.setText(C0274R.string.MVD);
            this.num = "8547639000";
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
    }

    public void onNothingSelected(AdapterView<?> adapterView) {
    }
}
