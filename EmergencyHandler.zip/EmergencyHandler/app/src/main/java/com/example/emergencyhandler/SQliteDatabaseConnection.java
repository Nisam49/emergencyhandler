package com.example.emergencyhandler;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class SQliteDatabaseConnection extends SQLiteOpenHelper {
    private static final String DATABASENAME = "doordie";
    private static final int DATABASEVERSION = 1;
    private static final String FIELD1 = "username";
    private static final String FIELD2 = "password";
    private static final String FIELD3 = "status";
    private static final String TABLENAME = "user";

    SQliteDatabaseConnection(Context context) {
        super(context, DATABASENAME, null, 1);
    }

    public void onCreate(SQLiteDatabase sq) {
        sq.execSQL("CREATE TABLE user(username TEXT,password TEXT,status TEXT)");
    }

    public void onUpgrade(SQLiteDatabase sq, int oldver, int newver) {
        sq.execSQL("DROP TABLE IF EXISTS user");
        onCreate(sq);
    }

    public void insertIntoTable(String username, String password, String status) {
        SQLiteDatabase sq = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(FIELD1, username);
        values.put(FIELD2, password);
        values.put("status", status);
        sq.insert(TABLENAME, null, values);
        sq.close();
    }

    public int getNumOfRows() {
        SQLiteDatabase sq = getReadableDatabase();
        Cursor cursor = sq.rawQuery("SELECT * FROM user", null);
        sq.close();
        return cursor.getCount();
    }

    public ArrayList getDataFromTable() {
        SQLiteDatabase sq = getReadableDatabase();
        ArrayList list = new ArrayList();
        Cursor cursor = sq.rawQuery("SELECT * FROM user", null);
        if (cursor.moveToFirst()) {
            do {
                list.add(cursor.getString(0));
                list.add(cursor.getString(1));
                list.add(cursor.getString(2));
            } while (cursor.moveToNext());
        }
        sq.close();
        return list;
    }

    public void truncateTable() {
        SQLiteDatabase sq = getWritableDatabase();
        sq.execSQL("DROP TABLE IF EXISTS user");
        onCreate(sq);
        sq.close();
    }
}
