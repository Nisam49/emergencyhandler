package com.example.emergencyhandler;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;

public class DODHelp extends Activity {
    /* renamed from: r */
    private RelativeLayout f4r;

    /* renamed from: coderzclub.doordie.DODHelp$1 */
    class C02451 implements OnClickListener {
        C02451() {
        }

        public void onClick(View v) {
            DODHelp.this.startActivity(new Intent(DODHelp.this.getApplicationContext(), DODfinal.class));
            DODHelp.this.finish();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0274R.layout.activity_dodhelp);
        this.f4r = (RelativeLayout) findViewById(C0274R.id.relativeLayout20);
        Editor editor = getSharedPreferences("mypref", 0).edit();
        editor.putString("MessageO", "Disable");
        editor.commit();
        this.f4r.setOnClickListener(new C02451());
    }
}
