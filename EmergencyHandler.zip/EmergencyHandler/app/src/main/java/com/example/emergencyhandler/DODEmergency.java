package com.example.emergencyhandler;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat.Builder;
import android.telephony.SmsManager;

public class DODEmergency extends Service implements SensorEventListener {
    int counts = 0;
    private float mAccel;
    private float mAccelCurrent;
    private float mAccelLast;
    private Sensor mAccelerometer;
    private SensorManager mSensorManager;

    /* renamed from: coderzclub.doordie.DODEmergency$1 */
    class C02431 extends BroadcastReceiver {
        C02431() {
        }

        public void onReceive(Context arg0, Intent arg1) {
            switch (getResultCode()) {
                case -1:
                    NotificationManager mgr12 = (NotificationManager) DODEmergency.this.getApplicationContext().getSystemService("notification");
                    Builder note12 = new Builder(DODEmergency.this.getApplicationContext());
                    note12.setContentTitle("Message Sent..");
                    note12.setContentText("DOD");
                    note12.setTicker("Message Sent.....");
                    note12.setAutoCancel(true);
                    note12.setSmallIcon(C0274R.drawable.ic_stat_name);
                    note12.setContentIntent(PendingIntent.getActivity(DODEmergency.this.getApplicationContext(), 0, new Intent(DODEmergency.this.getApplicationContext(), MainActivity.class), 0));
                    mgr12.notify(101, note12.build());
                    return;
                case 1:
                    NotificationManager mgr123 = (NotificationManager) DODEmergency.this.getApplicationContext().getSystemService("notification");
                    Builder note123 = new Builder(DODEmergency.this.getApplicationContext());
                    note123.setContentTitle("You Don't have Sufficient Balance..");
                    note123.setContentText("Recharge Your Phone..");
                    note123.setTicker("Error While Messaging..");
                    note123.setAutoCancel(true);
                    note123.setSmallIcon(C0274R.drawable.ic_stat_name);
                    note123.setContentIntent(PendingIntent.getActivity(DODEmergency.this.getApplicationContext(), 0, new Intent(DODEmergency.this.getApplicationContext(), MainActivity.class), 0));
                    mgr123.notify(101, note123.build());
                    return;
                case 2:
                    NotificationManager mgr1236 = (NotificationManager) DODEmergency.this.getApplicationContext().getSystemService("notification");
                    Builder note1236 = new Builder(DODEmergency.this.getApplicationContext());
                    note1236.setContentTitle("Network Radio is Off");
                    note1236.setContentText("Turn Off Airplane Mode..");
                    note1236.setTicker("Error While Messaging..");
                    note1236.setAutoCancel(true);
                    note1236.setSmallIcon(C0274R.drawable.ic_stat_name);
                    note1236.setContentIntent(PendingIntent.getActivity(DODEmergency.this.getApplicationContext(), 0, new Intent(DODEmergency.this.getApplicationContext(), MainActivity.class), 0));
                    mgr1236.notify(101, note1236.build());
                    return;
                case 3:
                    NotificationManager mgr1235 = (NotificationManager) DODEmergency.this.getApplicationContext().getSystemService("notification");
                    Builder note1235 = new Builder(DODEmergency.this.getApplicationContext());
                    note1235.setContentTitle("null pdu");
                    note1235.setContentText("Change DOD Settings..");
                    note1235.setTicker("Error While Messaging..");
                    note1235.setAutoCancel(true);
                    note1235.setSmallIcon(C0274R.drawable.ic_stat_name);
                    note1235.setContentIntent(PendingIntent.getActivity(DODEmergency.this.getApplicationContext(), 0, new Intent(DODEmergency.this.getApplicationContext(), MainActivity.class), 0));
                    mgr1235.notify(101, note1235.build());
                    return;
                case 4:
                    NotificationManager mgr1234 = (NotificationManager) DODEmergency.this.getApplicationContext().getSystemService("notification");
                    Builder note1234 = new Builder(DODEmergency.this.getApplicationContext());
                    note1234.setContentTitle("No Service..");
                    note1234.setContentText("Check Your Sim Connection..");
                    note1234.setTicker("Error While Messaging..");
                    note1234.setAutoCancel(true);
                    note1234.setSmallIcon(C0274R.drawable.ic_stat_name);
                    note1234.setContentIntent(PendingIntent.getActivity(DODEmergency.this.getApplicationContext(), 0, new Intent(DODEmergency.this.getApplicationContext(), MainActivity.class), 0));
                    mgr1234.notify(101, note1234.build());
                    return;
                default:
                    return;
            }
        }
    }

    /* renamed from: coderzclub.doordie.DODEmergency$2 */
    class C02442 extends BroadcastReceiver {
        C02442() {
        }

        public void onReceive(Context arg0, Intent arg1) {
            switch (getResultCode()) {
                case -1:
                    NotificationManager mgr1237y = (NotificationManager) DODEmergency.this.getApplicationContext().getSystemService("notification");
                    Builder note1237y = new Builder(DODEmergency.this.getApplicationContext());
                    note1237y.setContentTitle("Message Delivered..");
                    note1237y.setContentText("DOD");
                    note1237y.setTicker("Message Delivered..");
                    note1237y.setAutoCancel(true);
                    note1237y.setSmallIcon(C0274R.drawable.ic_stat_name);
                    note1237y.setContentIntent(PendingIntent.getActivity(DODEmergency.this.getApplicationContext(), 0, new Intent(DODEmergency.this.getApplicationContext(), MainActivity.class), 0));
                    mgr1237y.notify(101, note1237y.build());
                    return;
                case 0:
                    NotificationManager mgr1237 = (NotificationManager) DODEmergency.this.getApplicationContext().getSystemService("notification");
                    Builder note1237 = new Builder(DODEmergency.this.getApplicationContext());
                    note1237.setContentTitle("Message Canceled..");
                    note1237.setContentText("DOD");
                    note1237.setTicker("Error While Messaging..");
                    note1237.setAutoCancel(true);
                    note1237.setSmallIcon(C0274R.drawable.ic_stat_name);
                    note1237.setContentIntent(PendingIntent.getActivity(DODEmergency.this.getApplicationContext(), 0, new Intent(DODEmergency.this.getApplicationContext(), MainActivity.class), 0));
                    mgr1237.notify(101, note1237.build());
                    return;
                default:
                    return;
            }
        }
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
        this.mSensorManager = (SensorManager) getSystemService("sensor");
        this.mAccelerometer = this.mSensorManager.getDefaultSensor(1);
        this.mSensorManager.registerListener(this, this.mAccelerometer, 2, new Handler());
        return 1;
    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    public void onSensorChanged(SensorEvent event) {
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];
        this.mAccelLast = this.mAccelCurrent;
        this.mAccelCurrent = (float) Math.sqrt((double) (((x * x) + (y * y)) + (z * z)));
        this.mAccel = (this.mAccel * 0.9f) + (this.mAccelCurrent - this.mAccelLast);
        if (this.mAccel > 50.0f) {
            showNotification();
            if (this.counts == 1) {
                try {
                    DatabaseTest databaseTest = new DatabaseTest(getApplicationContext());
                    String no1 = String.valueOf(databaseTest.getDODPhone1());
                    String no2 = String.valueOf(databaseTest.getDODPhone2());
                    String msg = databaseTest.getDODMessage();
                    String SENT = "SMS_SENT";
                    String DELIVERED = "SMS_DELIVERED";
                    PendingIntent sentPI = PendingIntent.getBroadcast(this, 0, new Intent(SENT), 0);
                    PendingIntent deliveredPI = PendingIntent.getBroadcast(this, 0, new Intent(DELIVERED), 0);
                    registerReceiver(new C02431(), new IntentFilter(SENT));
                    registerReceiver(new C02442(), new IntentFilter(DELIVERED));
                    SmsManager sms = SmsManager.getDefault();
                    sms.sendTextMessage(no1, null, msg, sentPI, deliveredPI);
                    sms.sendTextMessage(no2, null, msg, sentPI, deliveredPI);
                } catch (Exception e) {
                    NotificationManager mgr12 = (NotificationManager) getSystemService("notification");
                    Builder builder = new Builder(this);
                    builder.setContentTitle("Permission Denied..");
                    builder.setContentText("Change App Settings.Enable Permission.");
                    builder.setTicker("Error While Messaging..");
                    builder.setAutoCancel(true);
                    builder.setSmallIcon(C0274R.drawable.ic_stat_name);
                    builder.setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), 0));
                    mgr12.notify(101, builder.build());
                }
                this.counts = 0;
            }
        }
    }

    private void showNotification() {
        this.counts++;
        NotificationManager mgr = (NotificationManager) getSystemService("notification");
        Builder note = new Builder(this);
        note.setAutoCancel(true);
        note.setDefaults(2);
        mgr.notify(101, note.build());
    }
}
