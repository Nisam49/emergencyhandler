package com.example.emergencyhandler;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class DOD extends AppCompatActivity {
    /* renamed from: b */
    Button f22b;
    /* renamed from: c */
    CheckBox f23c;
    DatabaseTest db;
    EditText e1;
    EditText e2;
    EditText e3;
    /* renamed from: p */
    ProgressBar f24p;
    SharedPreferences sharedpreferences;

    /* renamed from: coderzclub.doordie.DOD$1 */
    class C02411 implements OnClickListener {
        C02411() {
        }

        public void onClick(View v) {
            DOD.this.update();
        }
    }

    /* renamed from: coderzclub.doordie.DOD$2 */
    class C02422 implements OnCheckedChangeListener {
        C02422() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked) {
                Editor editor = DOD.this.sharedpreferences.edit();
                editor.putString("ButtonE", "Enable");
                editor.commit();
                Toast.makeText(DOD.this, "Button Enabled..", 0).show();
                return;
            }
            editor = DOD.this.sharedpreferences.edit();
            editor.putString("ButtonE", "Disable");
            editor.commit();
            Toast.makeText(DOD.this, "Button Disabled..", 0).show();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_dod);
        this.f24p = (ProgressBar) findViewById(C0274R.id.progressBar9);
        this.f24p.setVisibility(4);
        this.sharedpreferences = getSharedPreferences("mypref", 0);
        this.db = new DatabaseTest(getApplicationContext());
        this.e1 = (EditText) findViewById(C0274R.id.editText3);
        this.e1.setText(this.db.getDODMessage() + "");
        this.e2 = (EditText) findViewById(C0274R.id.editText4);
        this.e2.setText(this.db.getDODPhone1() + "");
        this.e3 = (EditText) findViewById(C0274R.id.editText5);
        this.e3.setText(this.db.getDODPhone2() + "");
        this.f22b = (Button) findViewById(C0274R.id.button7);
        this.f22b.setOnClickListener(new C02411());
        this.f23c = (CheckBox) findViewById(C0274R.id.checkBox2);
        if (this.sharedpreferences.getString("ButtonE", "").equals("Enable")) {
            this.f23c.setChecked(true);
        } else {
            this.f23c.setChecked(false);
        }
        this.f23c.setOnCheckedChangeListener(new C02422());
    }

    public void onRestart() {
        super.onRestart();
        finish();
    }

    public boolean update() {
        Toast.makeText(this, "Updating..Please Wait...", 1).show();
        this.f24p.setVisibility(0);
        String msg = this.e1.getText().toString();
        String ph1 = this.e2.getText().toString();
        String ph2 = this.e3.getText().toString();
        if (ph1.length() == 10 && ph2.length() == 10) {
            new dodjson(getApplicationContext()).execute(new String[]{ph1, ph2, this.db.getUsername(), msg});
            return true;
        }
        Toast.makeText(this, "Invalid Phone Number...", 0).show();
        return false;
    }
}
