package com.example.emergencyhandler;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class TermsAndConditions extends AppCompatActivity {
    Button agr;
    Button dgr;

    /* renamed from: coderzclub.doordie.TermsAndConditions$1 */
    class C02841 implements OnClickListener {
        C02841() {
        }

        public void onClick(View v) {
            TermsAndConditions.this.finish();
        }
    }

    /* renamed from: coderzclub.doordie.TermsAndConditions$2 */
    class C02852 implements OnClickListener {
        C02852() {
        }

        public void onClick(View v) {
            TermsAndConditions.this.startActivity(new Intent(TermsAndConditions.this.getApplicationContext(), LoginActivity.class));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_terms_and_conditions);
        this.agr = (Button) findViewById(C0274R.id.button4);
        this.dgr = (Button) findViewById(C0274R.id.button5);
        this.dgr.setOnClickListener(new C02841());
        this.agr.setOnClickListener(new C02852());
    }
}
