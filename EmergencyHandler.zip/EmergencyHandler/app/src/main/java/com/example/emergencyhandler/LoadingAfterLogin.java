package com.example.emergencyhandler;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LoadingAfterLogin extends Activity {
    /* renamed from: b */
    Bundle f5b;
    /* renamed from: p */
    ProgressBar f6p;
    String[] values;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0274R.layout.activity_loading_after_login);
        this.f6p = (ProgressBar) findViewById(C0274R.id.progressBar);
        this.f5b = getIntent().getExtras();
        String usern = this.f5b.getString("useusername");
        getJSON("http://codersclub.000webhostapp.com/getdata.php?username=" + usern + "&password=" + this.f5b.getString("usepassword"));
    }

    private void getJSON(final String urlWebService) {
        new AsyncTask<Void, Void, String>() {
            protected void onPreExecute() {
                super.onPreExecute();
            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                LoadingAfterLogin.this.f6p.setProgress(30);
                try {
                    LoadingAfterLogin.this.loadIntoListView(s);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            protected String doInBackground(Void... voids) {
                try {
                    HttpURLConnection con = (HttpURLConnection) new URL(urlWebService).openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    while (true) {
                        String json = bufferedReader.readLine();
                        if (json == null) {
                            return sb.toString().trim();
                        }
                        sb.append(json + "\n");
                    }
                } catch (Exception e) {
                    return null;
                }
            }
        }.execute(new Void[0]);
    }

    private void loadIntoListView(String json) throws JSONException {
        JSONArray jsonArray = new JSONArray(json);
        this.values = new String[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);
            this.values[i] = obj.getString("name");
        }
        this.f6p.setProgress(50);
        DatabaseTest d = new DatabaseTest(getApplicationContext());
        d.truncateTable();
        d.insertIntoTable(this.values[0], this.values[1], this.values[2], this.values[3], this.values[4], this.values[5], this.values[6], this.values[7], this.values[8], this.values[9], this.values[10]);
        if (!d.setDatatoDOD("Help", this.values[9], this.values[10])) {
            Toast.makeText(this, "Unable to insert", 0).show();
        }
        this.f6p.setProgress(90);
        startActivity(new Intent(getApplicationContext(), DrawerActivity.class));
        Editor editor = getSharedPreferences("mypref", 0).edit();
        editor.putString("ButtonE", "Disable");
        editor.putString("MessageR", "Enable");
        editor.putString("MessageO", "Enable");
        editor.putString("MessageB", "Enable");
        editor.commit();
        finish();
    }
}
