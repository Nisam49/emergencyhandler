package com.example.emergencyhandler;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class ChangePassword extends AppCompatActivity {
    /* renamed from: b */
    Button f20b;
    DatabaseTest db;
    EditText e1;
    EditText e2;
    /* renamed from: p */
    ProgressBar f21p;

    /* renamed from: coderzclub.doordie.ChangePassword$1 */
    class C02401 implements OnClickListener {
        C02401() {
        }

        public void onClick(View v) {
            try {
                if (ChangePassword.this.e1.getText().toString().equals(ChangePassword.this.db.getPassword())) {
                    String pass = ChangePassword.this.e2.getText().toString();
                    Toast.makeText(ChangePassword.this, "Please Wait..Password Updating... ", 0).show();
                    ChangePassword.this.f21p.setVisibility(0);
                    new passwordjson(ChangePassword.this.getApplicationContext()).execute(new String[]{pass, ChangePassword.this.db.getUsername()});
                    return;
                }
                Toast.makeText(ChangePassword.this, "Wrong Current Password...", 0).show();
            } catch (Exception e) {
                Toast.makeText(ChangePassword.this, "Something Wrong..." + e, 0).show();
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_change_password);
        this.db = new DatabaseTest(getApplicationContext());
        this.e1 = (EditText) findViewById(C0274R.id.curp);
        this.e2 = (EditText) findViewById(C0274R.id.newp);
        this.f20b = (Button) findViewById(C0274R.id.upp);
        this.f21p = (ProgressBar) findViewById(C0274R.id.progressBar6);
        this.f21p.setVisibility(4);
        this.f20b.setOnClickListener(new C02401());
    }

    public void onRestart() {
        super.onRestart();
        finish();
    }
}
