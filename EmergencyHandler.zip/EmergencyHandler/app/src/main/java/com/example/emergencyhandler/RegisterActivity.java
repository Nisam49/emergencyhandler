package com.example.emergencyhandler;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    EditText address;
    String addresstos;
    EditText age;
    String agetos;
    RadioButton br;
    Button bu;
    CheckBox ch;
    EditText cpass;
    String cpasstos;
    EditText email;
    String emailtos;
    EditText location;
    String locationtos;
    EditText name;
    String nametos;
    DatabaseTest obj;
    /* renamed from: p */
    ProgressBar f44p;
    EditText pass;
    String passtos;
    String pf1;
    String pf2;
    EditText phone;
    EditText phone1;
    EditText phone2;
    String phonetos;
    RadioGroup radioGroup;
    EditText username;
    String usernametos;

    /* renamed from: coderzclub.doordie.RegisterActivity$1 */
    class C02751 implements OnClickListener {
        C02751() {
        }

        public void onClick(View v) {
            try {
                RegisterActivity.this.startActivity(new Intent(RegisterActivity.this.getApplicationContext(), TermsAndConditions.class));
                RegisterActivity.this.ch.setChecked(true);
            } catch (Exception e) {
                Toast.makeText(RegisterActivity.this.getApplicationContext(), e + "", 0).show();
            }
        }
    }

    /* renamed from: coderzclub.doordie.RegisterActivity$2 */
    class C02762 implements OnClickListener {
        C02762() {
        }

        public void onClick(View v) {
            try {
                if (!RegisterActivity.this.checkFields()) {
                    Toast.makeText(RegisterActivity.this.getApplicationContext(), "Some Fields are Missing..", 0).show();
                } else if (!RegisterActivity.this.checkRadio()) {
                    Toast.makeText(RegisterActivity.this.getApplicationContext(), "", 0).show();
                } else if (!RegisterActivity.this.checkAge()) {
                    Toast.makeText(RegisterActivity.this.getApplicationContext(), "Age must greater than 14", 0).show();
                } else if (!RegisterActivity.this.checkPhone()) {
                    Toast.makeText(RegisterActivity.this.getApplicationContext(), "Not a Valid Phone Number", 0).show();
                } else if (!RegisterActivity.this.checkEmail()) {
                    Toast.makeText(RegisterActivity.this.getApplicationContext(), "Not a Valid Email..", 0).show();
                } else if (!RegisterActivity.this.checkPassword()) {
                    Toast.makeText(RegisterActivity.this.getApplicationContext(), "Passwords do not match..", 0).show();
                } else if (!RegisterActivity.this.checkFriendnumber1()) {
                    Toast.makeText(RegisterActivity.this.getApplicationContext(), "Invalid Phone Number of Friend 1...", 0).show();
                } else if (!RegisterActivity.this.checkFriendnumber2()) {
                    Toast.makeText(RegisterActivity.this.getApplicationContext(), "Invalid Phone Number of Friend 2...", 0).show();
                } else if (RegisterActivity.this.checkConditions()) {
                    RegisterActivity.this.f44p.setVisibility(0);
                    RegisterActivity.this.setAllDataMysql();
                } else {
                    Toast.makeText(RegisterActivity.this.getApplicationContext(), "Agree Our Conditions", 0).show();
                }
            } catch (Exception e) {
                Toast.makeText(RegisterActivity.this.getApplicationContext(), "Choose Gender..", 0).show();
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_register);
        this.age = (EditText) findViewById(C0274R.id.newp);
        this.ch = (CheckBox) findViewById(C0274R.id.checkBox);
        this.name = (EditText) findViewById(C0274R.id.curp);
        this.address = (EditText) findViewById(C0274R.id.addressu);
        this.email = (EditText) findViewById(C0274R.id.email);
        this.pass = (EditText) findViewById(C0274R.id.password);
        this.cpass = (EditText) findViewById(C0274R.id.cpassword);
        this.username = (EditText) findViewById(C0274R.id.username);
        this.phone = (EditText) findViewById(C0274R.id.phoneu);
        this.location = (EditText) findViewById(C0274R.id.locationu);
        this.radioGroup = (RadioGroup) findViewById(C0274R.id.radioGroup);
        this.bu = (Button) findViewById(C0274R.id.button2);
        this.phone1 = (EditText) findViewById(C0274R.id.ph1);
        this.phone2 = (EditText) findViewById(C0274R.id.ph2);
        this.f44p = (ProgressBar) findViewById(C0274R.id.progressBar5);
        this.f44p.setVisibility(4);
        this.obj = new DatabaseTest(getApplicationContext());
        this.ch.setOnClickListener(new C02751());
        this.bu.setOnClickListener(new C02762());
    }

    public void onRestart() {
        super.onRestart();
        finish();
    }

    public boolean checkAge() {
        return Integer.parseInt(this.age.getText().toString()) >= 14;
    }

    public boolean checkPassword() {
        return this.pass.getText().toString().equals(this.cpass.getText().toString());
    }

    public boolean checkPhone() {
        String p = this.phone.getText().toString();
        return p.length() >= 10 && p.length() <= 10;
    }

    public boolean checkEmail() {
        String em = this.email.getText().toString();
        return em.contains("@") && em.contains(".");
    }

    public boolean checkRadio() {
        this.br = (RadioButton) findViewById(this.radioGroup.getCheckedRadioButtonId());
        return this.br.isChecked();
    }

    public boolean checkFields() {
        this.nametos = this.name.getText().toString();
        this.agetos = this.age.getText().toString();
        this.phonetos = this.phone.getText().toString();
        this.passtos = this.pass.getText().toString();
        this.cpasstos = this.cpass.getText().toString();
        this.emailtos = this.email.getText().toString();
        this.locationtos = this.location.getText().toString();
        this.addresstos = this.address.getText().toString();
        this.usernametos = this.username.getText().toString();
        this.pf1 = this.phone1.getText().toString();
        this.pf2 = this.phone2.getText().toString();
        return (this.nametos.isEmpty() || this.agetos.isEmpty() || this.addresstos.isEmpty() || this.passtos.isEmpty() || this.cpasstos.isEmpty() || this.phonetos.isEmpty() || this.emailtos.isEmpty() || this.addresstos.isEmpty() || this.usernametos.isEmpty() || this.pf2.isEmpty() || this.pf2.isEmpty()) ? false : true;
    }

    public boolean checkConditions() {
        return this.ch.isChecked();
    }

    public void setAllDataSQlite() {
        try {
            this.nametos = this.name.getText().toString();
            this.agetos = this.age.getText().toString();
            this.phonetos = this.phone.getText().toString();
            this.passtos = this.pass.getText().toString();
            this.cpasstos = this.cpass.getText().toString();
            this.emailtos = this.email.getText().toString();
            this.locationtos = this.location.getText().toString();
            this.addresstos = this.address.getText().toString();
            this.usernametos = this.username.getText().toString();
            this.pf1 = this.phone1.getText().toString();
            this.pf2 = this.phone2.getText().toString();
            this.obj.insertIntoTable(this.nametos, this.agetos, this.br.getText().toString(), this.addresstos, this.locationtos, this.phonetos, this.emailtos, this.pf1, this.pf2, this.usernametos, this.passtos);
            Toast.makeText(getApplicationContext(), "You are Registered Successfully..You Can Login Now...", 0).show();
            finish();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Something Wrong " + e, 0).show();
        }
    }

    public boolean checkFriendnumber1() {
        String p = this.phone1.getText().toString();
        return p.length() <= 10 && p.length() >= 10;
    }

    public boolean checkFriendnumber2() {
        String p = this.phone2.getText().toString();
        return p.length() <= 10 && p.length() >= 10;
    }

    public void setAllDataMysql() {
        try {
            this.nametos = this.name.getText().toString();
            this.agetos = this.age.getText().toString();
            this.phonetos = this.phone.getText().toString();
            this.passtos = this.pass.getText().toString();
            this.cpasstos = this.cpass.getText().toString();
            this.emailtos = this.email.getText().toString();
            this.locationtos = this.location.getText().toString();
            this.addresstos = this.address.getText().toString();
            this.usernametos = this.username.getText().toString();
            this.pf1 = this.phone1.getText().toString();
            this.pf2 = this.phone2.getText().toString();
            Toast.makeText(this, "Signing up...", 0).show();
            try {
                new oowebhost_mysql_connect(this).execute(new String[]{this.nametos, this.agetos, this.br.getText().toString(), this.addresstos, this.locationtos, this.phonetos, this.emailtos, this.usernametos, this.passtos, this.pf1, this.pf2});
            } catch (Exception e) {
                Toast.makeText(this, e + "", 0).show();
            }
            Toast.makeText(getApplicationContext(), "Signing In..Please Wait..", 0).show();
        } catch (Exception e2) {
            Toast.makeText(getApplicationContext(), "Something Wrong " + e2, 0).show();
        }
    }
}
