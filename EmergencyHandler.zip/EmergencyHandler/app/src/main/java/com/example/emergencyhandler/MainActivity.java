package com.example.emergencyhandler;

import android.content.Intent;
import android.content.Intent.ShortcutIconResource;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements Runnable {
    /* renamed from: a */
    int f39a;
    SharedPreferences appPreferences;
    DatabaseTest db;
    /* renamed from: f */
    ProgressBar f40f;
    boolean isAppInstalled = false;
    SharedPreferences sharedPreferences;
    TextView th;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_main);
        this.f40f = (ProgressBar) findViewById(C0274R.id.progressBar11);
        this.th = (TextView) findViewById(C0274R.id.textView47);
        this.appPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        this.isAppInstalled = this.appPreferences.getBoolean("isAppInstalled", false);
        if (!this.isAppInstalled) {
            Intent shortcutIntent = new Intent(getApplicationContext(), DODWidgetActivity.class);
            shortcutIntent.setAction("android.intent.action.MAIN");
            Intent intent = new Intent();
            intent.putExtra("android.intent.extra.shortcut.INTENT", shortcutIntent);
            intent.putExtra("android.intent.extra.shortcut.NAME", "DOD");
            intent.putExtra("android.intent.extra.shortcut.ICON_RESOURCE", ShortcutIconResource.fromContext(getApplicationContext(), C0274R.mipmap.widgeticon));
            intent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
            getApplicationContext().sendBroadcast(intent);
            Editor editor = this.appPreferences.edit();
            editor.putBoolean("isAppInstalled", true);
            editor.commit();
        }
        this.sharedPreferences = getSharedPreferences("mypref", 0);
        if (!this.sharedPreferences.contains("count")) {
            Editor edit = this.sharedPreferences.edit();
            edit.putString("count", "0");
            edit.commit();
        }
        this.f39a = new DatabaseTest(getApplicationContext()).getNumOfRows();
        new Thread(this).start();
    }

    public void run() {
        int it = 1;
        while (it <= 100) {
            try {
                this.f40f.setProgress(it);
                Thread.sleep(30);
                it++;
            } catch (Exception e) {
                Toast.makeText(this, e + " ", 0).show();
                return;
            }
        }
        if (this.f39a == 0) {
            startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        } else {
            startActivity(new Intent(getApplicationContext(), DrawerActivity.class));
        }
        finish();
    }
}
