package com.example.emergencyhandler;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;
import com.google.android.gms.drive.DriveFile;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import org.json.JSONException;
import org.json.JSONObject;

public class oowebhost_mysql_connect extends AsyncTask<String, Void, String> {
    String addresstos;
    String agetos;
    private Context context;
    String emailtos;
    String gendertos;
    String locationtos;
    String nametos;
    String passtos;
    String pf1;
    String pf2;
    String phonetos;
    String usernametos;

    public oowebhost_mysql_connect(Context context) {
        this.context = context;
    }

    protected void onPreExecute() {
    }

    protected String doInBackground(String... arg0) {
        this.nametos = arg0[0];
        this.agetos = arg0[1];
        this.gendertos = arg0[2];
        this.addresstos = arg0[3];
        this.locationtos = arg0[4];
        this.phonetos = arg0[5];
        this.emailtos = arg0[6];
        this.usernametos = arg0[7];
        this.passtos = arg0[8];
        this.pf1 = arg0[9];
        this.pf2 = arg0[10];
        try {
            return new BufferedReader(new InputStreamReader(((HttpURLConnection) new URL("https://codersclub.000webhostapp.com/signup.php" + ((((((((((("?name=" + URLEncoder.encode(this.nametos, "UTF-8")) + "&age=" + URLEncoder.encode(this.agetos, "UTF-8")) + "&gender=" + URLEncoder.encode(this.gendertos, "UTF-8")) + "&phone=" + URLEncoder.encode(this.phonetos, "UTF-8")) + "&email=" + URLEncoder.encode(this.emailtos, "UTF-8")) + "&location=" + URLEncoder.encode(this.locationtos, "UTF-8")) + "&address=" + URLEncoder.encode(this.addresstos, "UTF-8")) + "&username=" + URLEncoder.encode(this.usernametos, "UTF-8")) + "&password=" + URLEncoder.encode(this.passtos, "UTF-8")) + "&phone1=" + URLEncoder.encode(this.pf1, "UTF-8")) + "&phone2=" + URLEncoder.encode(this.pf2, "UTF-8"))).openConnection()).getInputStream())).readLine();
        } catch (Exception e) {
            return new String("Exception: " + e.getMessage());
        }
    }

    protected void onPostExecute(String result) {
        String jsonStr = result;
        if (jsonStr != null) {
            try {
                String query_result = new JSONObject(jsonStr).getString("query_result");
                if (query_result.equals("SUCCESS")) {
                    Toast.makeText(this.context, "Signup Successful...You Can Now Login", 0).show();
                    Intent i = new Intent(this.context, LoginActivity.class);
                    i.addFlags(DriveFile.MODE_READ_ONLY);
                    this.context.startActivity(i);
                    return;
                } else if (query_result.equals("FAILURE")) {
                    Toast.makeText(this.context, "Try Different Username....", 0).show();
                    return;
                } else if (query_result.equals("ERROR")) {
                    Toast.makeText(this.context, "Couldn't connect to Remote database...Try Again", 0).show();
                    return;
                } else {
                    return;
                }
            } catch (JSONException e) {
                e.printStackTrace();
                Toast.makeText(this.context, "Bad Internet Connection...Try Again...", 0).show();
                return;
            }
        }
        Toast.makeText(this.context, "Bad Internet Connection...Try Again...", 0).show();
    }
}
