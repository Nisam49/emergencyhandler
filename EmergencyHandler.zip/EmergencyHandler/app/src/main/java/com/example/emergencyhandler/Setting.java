package com.example.emergencyhandler;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

public class Setting extends AppCompatActivity implements OnClickListener {
    TextView t1;
    TextView t2;
    TextView t3;
    TextView t4;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_setting);
        this.t1 = (TextView) findViewById(C0274R.id.textView22);
        this.t2 = (TextView) findViewById(C0274R.id.textView23);
        this.t3 = (TextView) findViewById(C0274R.id.textView24);
        this.t4 = (TextView) findViewById(C0274R.id.textView25);
        this.t1.setOnClickListener(this);
        this.t2.setOnClickListener(this);
        this.t3.setOnClickListener(this);
        this.t4.setOnClickListener(this);
    }

    public void onClick(View v) {
        try {
            if (v.getId() == this.t1.getId()) {
                startActivity(new Intent(getApplicationContext(), EditProfile.class));
            } else if (v.getId() == this.t2.getId()) {
                startActivity(new Intent(getApplicationContext(), ChangePassword.class));
            } else if (v.getId() == this.t3.getId()) {
                startActivity(new Intent(getApplicationContext(), DOD.class));
            } else if (v.getId() == this.t4.getId()) {
                startActivity(new Intent(getApplicationContext(), DeleteAccount.class));
            }
        } catch (Exception e) {
            Toast.makeText(this, "Something Wrong " + e, 0).show();
        }
    }
}
