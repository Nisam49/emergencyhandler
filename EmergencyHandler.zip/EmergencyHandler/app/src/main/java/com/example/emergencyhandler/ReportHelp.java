package com.example.emergencyhandler;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;

public class ReportHelp extends Activity {
    /* renamed from: r */
    RelativeLayout f10r;

    /* renamed from: coderzclub.doordie.ReportHelp$1 */
    class C02811 implements OnClickListener {
        C02811() {
        }

        public void onClick(View v) {
            ReportHelp.this.startActivity(new Intent(ReportHelp.this.getApplicationContext(), Report.class));
            ReportHelp.this.finish();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0274R.layout.activity_report_help);
        this.f10r = (RelativeLayout) findViewById(C0274R.id.relativeLayout20);
        Editor editor = getSharedPreferences("mypref", 0).edit();
        editor.putString("MessageR", "Disable");
        editor.commit();
        this.f10r.setOnClickListener(new C02811());
    }
}
