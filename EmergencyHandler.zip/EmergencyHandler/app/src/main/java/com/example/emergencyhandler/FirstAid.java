package com.example.emergencyhandler;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class FirstAid extends AppCompatActivity {
    WebView view;

    /* renamed from: coderzclub.doordie.FirstAid$1 */
    class C02651 extends WebViewClient {
        C02651() {
        }

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_first_aid);
        this.view = (WebView) findViewById(C0274R.id.webView);
        this.view.getSettings().setJavaScriptEnabled(true);
        this.view.setWebViewClient(new C02651());
        this.view.loadUrl("https://codersclub.000webhostapp.com/first_aid/category.html");
    }

    public void onBackPressed() {
        if (this.view.canGoBack()) {
            this.view.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
