package com.example.emergencyhandler;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class DatabaseTest extends SQLiteOpenHelper {
    private static final String DATABASENAME = "doordietest";
    private static final int DATABASEVERSION = 1;
    private static final String FIELD1 = "Name";
    private static final String FIELD10 = "Phone_Of_Friend1";
    private static final String FIELD11 = "Phone_Of_Friend2";
    private static final String FIELD2 = "Age";
    private static final String FIELD3 = "Gender";
    private static final String FIELD4 = "Address";
    private static final String FIELD5 = "Location";
    private static final String FIELD6 = "Phone";
    private static final String FIELD7 = "Email";
    private static final String FIELD8 = "Username";
    private static final String FIELD9 = "Password";
    private static final String NFIELD1 = "Message";
    private static final String NFIELD2 = "Phone1";
    private static final String NFIELD3 = "Phone2";
    private static final String NTABLE1 = "DOD";
    private static final String TABLENAME = "registered";

    DatabaseTest(Context context) {
        super(context, DATABASENAME, null, 1);
    }

    public void onCreate(SQLiteDatabase sq) {
        sq.execSQL("CREATE TABLE registered(Name TEXT,Age TEXT,Gender TEXT,Address TEXT,Location TEXT,Phone TEXT,Email TEXT,Phone_Of_Friend1 TEXT,Phone_Of_Friend2 TEXT,Username TEXT,Password TEXT)");
        sq.execSQL("CREATE TABLE DOD(Message TEXT,Phone1 TEXT,Phone2 TEXT)");
    }

    public void onUpgrade(SQLiteDatabase sq, int oldver, int newver) {
        sq.execSQL("DROP TABLE IF EXISTS registered");
        sq.execSQL("DROP TABLE IF EXISTS DOD");
        onCreate(sq);
    }

    public void insertIntoTable(String name, String age, String gender, String address, String location, String phone, String email, String phone1, String phone2, String username, String password) {
        SQLiteDatabase sq = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(FIELD1, name);
        values.put(FIELD2, age);
        values.put(FIELD3, gender);
        values.put(FIELD4, address);
        values.put(FIELD5, location);
        values.put(FIELD6, phone);
        values.put(FIELD7, email);
        values.put(FIELD8, username);
        values.put(FIELD9, password);
        values.put(FIELD10, phone1);
        values.put(FIELD11, phone2);
        sq.insert(TABLENAME, null, values);
        sq.close();
    }

    public int getNumOfRows() {
        return getReadableDatabase().rawQuery("SELECT * FROM registered", null).getCount();
    }

    public ArrayList getDataFromTable() {
        SQLiteDatabase sq = getReadableDatabase();
        ArrayList list = new ArrayList();
        Cursor cursor = sq.rawQuery("SELECT * FROM registered", null);
        if (cursor.moveToFirst()) {
            do {
                list.add(cursor.getString(0));
                list.add(cursor.getString(1));
                list.add(cursor.getString(2));
                list.add(cursor.getString(3));
                list.add(cursor.getString(4));
                list.add(cursor.getString(5));
                list.add(cursor.getString(6));
                list.add(cursor.getString(7));
                list.add(cursor.getString(8));
                list.add(cursor.getString(9));
                list.add(cursor.getString(10));
            } while (cursor.moveToNext());
        }
        sq.close();
        return list;
    }

    public void truncateTable() {
        SQLiteDatabase sq = getWritableDatabase();
        sq.execSQL("DROP TABLE IF EXISTS registered");
        sq.execSQL("DROP TABLE IF EXISTS DOD");
        onCreate(sq);
        sq.close();
    }

    public boolean checkingLogin(String username, String password) {
        SQLiteDatabase sq = getReadableDatabase();
        String musername = "\"" + username + "\"";
        return sq.rawQuery("SELECT * FROM registered WHERE Username=" + musername + " and " + FIELD9 + "=" + ("\"" + password + "\""), null).moveToFirst();
    }

    public void updatePasswordfromUsername(String username, String newPass) {
        String getUser = "\"" + username + "\"";
        String pass = "\"" + newPass + "\"";
        SQLiteDatabase sq = getWritableDatabase();
        try {
            ContentValues c = new ContentValues();
            c.put(FIELD9, newPass);
            sq.update(TABLENAME, c, "Username=" + getUser, null);
        } catch (Exception e) {
            sq.execSQL("UPDATE registered SET Password=" + pass + " WHERE " + FIELD8 + "=" + getUser);
            sq.close();
        }
    }

    public boolean setDatatoDOD(String Message, String Phone1, String Phone2) {
        try {
            SQLiteDatabase sq = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(NFIELD1, Message);
            values.put(NFIELD2, Phone1);
            values.put(NFIELD3, Phone2);
            sq.insert(NTABLE1, null, values);
            sq.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public void updateDatatoDOD(String Message, String Phone1, String Phone2) {
        SQLiteDatabase sq = getWritableDatabase();
        String nmessage = "\"" + Message + "\"";
        String nphone1 = "\"" + Phone1 + "\"";
        try {
            sq.execSQL("UPDATE DOD SET Message=" + nmessage + ",Phone1=" + nphone1 + ",Phone2=" + ("\"" + Phone2 + "\""));
        } catch (Exception e) {
            ContentValues c = new ContentValues();
            c.put(NFIELD1, Message);
            c.put(NFIELD2, Phone1);
            c.put(NFIELD3, Phone2);
            sq.update(NTABLE1, c, null, null);
            sq.close();
        }
    }

    public void updateFromActivity(String name, String Age, String Address, String location, String phone, String email) {
        SQLiteDatabase sq = getWritableDatabase();
        String nname = "\"" + name + "\"";
        String nage = "\"" + Age + "\"";
        String nadd = "\"" + Address + "\"";
        String nloc = "\"" + location + "\"";
        String nph = "\"" + phone + "\"";
        try {
            sq.execSQL("UPDATE registered SET Name=" + nname + "," + FIELD2 + "=" + nage + "," + FIELD4 + "=" + nadd + "," + FIELD5 + "=" + nloc + "," + FIELD6 + "=" + nph + "," + FIELD7 + "=" + ("\"" + email + "\""));
        } catch (Exception e) {
            ContentValues c = new ContentValues();
            c.put(FIELD1, name);
            c.put(FIELD2, Age);
            c.put(FIELD4, Address);
            c.put(FIELD5, location);
            c.put(FIELD6, phone);
            c.put(FIELD7, email);
            sq.update(TABLENAME, c, null, null);
            sq.close();
        }
    }

    public String getDODMessage() {
        String message = "";
        try {
            Cursor cursorb = getReadableDatabase().rawQuery("SELECT * FROM DOD", null);
            if (cursorb.moveToFirst()) {
                message = cursorb.getString(0);
            }
            return message;
        } catch (Exception e) {
            return "Data Not Available...";
        }
    }

    public String getDODPhone1() {
        String pnum1 = "";
        try {
            Cursor cursorc = getReadableDatabase().rawQuery("SELECT * FROM DOD", null);
            if (cursorc.moveToFirst()) {
                pnum1 = cursorc.getString(1).toString();
            }
            return pnum1;
        } catch (Exception e) {
            return "Something Wrong...";
        }
    }

    public String getDODPhone2() {
        String pnum2 = "";
        try {
            Cursor cursord = getReadableDatabase().rawQuery("SELECT * FROM DOD", null);
            if (cursord.moveToFirst()) {
                pnum2 = cursord.getString(2).toString();
            }
            return pnum2;
        } catch (Exception e) {
            return "Something Wrong..";
        }
    }

    public int getCountDOD() {
        return getReadableDatabase().rawQuery("SELECT * FROM DOD", null).getCount();
    }

    public String getUsername() {
        Cursor cursor = getReadableDatabase().rawQuery("SELECT * FROM registered", null);
        if (cursor.moveToFirst()) {
            return cursor.getString(7);
        }
        return "";
    }

    public String getPassword() {
        Cursor cursor = getReadableDatabase().rawQuery("SELECT * FROM registered", null);
        if (cursor.moveToFirst()) {
            return cursor.getString(8);
        }
        return "";
    }

    public String getName() {
        Cursor cursor = getReadableDatabase().rawQuery("SELECT * FROM registered", null);
        if (cursor.moveToFirst()) {
            return cursor.getString(0);
        }
        return "";
    }

    public String getEmail() {
        Cursor cursor = getReadableDatabase().rawQuery("SELECT * FROM registered", null);
        if (cursor.moveToFirst()) {
            return cursor.getString(6);
        }
        return "";
    }

    public String getPhone() {
        Cursor cursor = getReadableDatabase().rawQuery("SELECT * FROM registered", null);
        if (cursor.moveToFirst()) {
            return cursor.getString(5);
        }
        return "";
    }

    public void updatePassword(String pass) {
        SQLiteDatabase sq = getWritableDatabase();
        String nname = "\"" + pass + "\"";
        try {
            sq.execSQL("UPDATE registered SET Password=" + nname);
        } catch (Exception e) {
            ContentValues c = new ContentValues();
            c.put(FIELD9, nname);
            sq.update(TABLENAME, c, null, null);
            sq.close();
        }
    }

    public void updatePhones(String ph1, String ph2) {
        SQLiteDatabase sq = getWritableDatabase();
        String nname = "\"" + ph1 + "\"";
        String nname1 = "\"" + ph2 + "\"";
        try {
            sq.execSQL("UPDATE registered SET Phone_Of_Friend1=" + nname + "," + FIELD11 + "=" + nname1);
        } catch (Exception e) {
            ContentValues c = new ContentValues();
            c.put(FIELD10, nname);
            c.put(FIELD11, nname1);
            sq.update(TABLENAME, c, null, null);
            sq.close();
        }
    }
}
