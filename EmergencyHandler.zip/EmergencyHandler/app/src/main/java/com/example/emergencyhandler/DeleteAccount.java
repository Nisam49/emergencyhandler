package com.example.emergencyhandler;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class DeleteAccount extends AppCompatActivity {
    /* renamed from: B */
    Button f29B;
    DatabaseTest db;
    /* renamed from: e */
    EditText f30e;
    /* renamed from: p */
    ProgressBar f31p;

    /* renamed from: coderzclub.doordie.DeleteAccount$1 */
    class C02521 implements OnClickListener {
        C02521() {
        }

        public void onClick(View v) {
            Toast.makeText(DeleteAccount.this, "Please Wait...", 0).show();
            DeleteAccount.this.f31p.setVisibility(0);
            if (DeleteAccount.this.f30e.getText().toString().equals(DeleteAccount.this.db.getUsername())) {
                new deleteaccjson(DeleteAccount.this.getApplicationContext()).execute(new String[]{DeleteAccount.this.db.getUsername()});
                return;
            }
            Toast.makeText(DeleteAccount.this, "Wrong Username....Try Again..", 0).show();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_delete_account);
        this.f31p = (ProgressBar) findViewById(C0274R.id.progressBar8);
        this.f31p.setVisibility(4);
        this.db = new DatabaseTest(getApplicationContext());
        try {
            this.f29B = (Button) findViewById(C0274R.id.button3);
            this.f30e = (EditText) findViewById(C0274R.id.editText6);
            this.f29B.setOnClickListener(new C02521());
        } catch (Exception e) {
            Toast.makeText(this, e + "", 0).show();
        }
    }

    public void onRestart() {
        super.onRestart();
        finish();
    }
}
