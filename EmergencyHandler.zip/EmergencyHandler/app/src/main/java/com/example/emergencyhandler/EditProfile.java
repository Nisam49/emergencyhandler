package com.example.emergencyhandler;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import java.util.ArrayList;

public class EditProfile extends AppCompatActivity implements OnClickListener {
    /* renamed from: a */
    EditText f32a;
    EditText add;
    String address;
    String age;
    /* renamed from: b */
    Button f33b;
    DatabaseTest databaseTest;
    EditText em;
    String email;
    EditText loc;
    String location;
    /* renamed from: n */
    EditText f34n;
    String name;
    /* renamed from: p */
    ProgressBar f35p;
    EditText ph;
    String phone;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_edit_profile);
        this.f34n = (EditText) findViewById(C0274R.id.curp);
        this.f32a = (EditText) findViewById(C0274R.id.newp);
        this.add = (EditText) findViewById(C0274R.id.addressu);
        this.loc = (EditText) findViewById(C0274R.id.locationu);
        this.ph = (EditText) findViewById(C0274R.id.phoneu);
        this.em = (EditText) findViewById(C0274R.id.emailu);
        this.f33b = (Button) findViewById(C0274R.id.button12);
        this.f35p = (ProgressBar) findViewById(C0274R.id.progressBar7);
        this.f35p.setVisibility(4);
        this.databaseTest = new DatabaseTest(getApplicationContext());
        setTOUpdate();
        this.f33b.setOnClickListener(this);
    }

    public void onRestart() {
        super.onRestart();
        finish();
    }

    public void setTOUpdate() {
        try {
            ArrayList list = this.databaseTest.getDataFromTable();
            this.name = list.get(0).toString();
            this.age = list.get(1).toString();
            this.address = list.get(3).toString();
            this.location = list.get(4).toString();
            this.phone = list.get(5).toString();
            this.email = list.get(6).toString();
            this.f34n.setText(this.name + "");
            this.f32a.setText(this.age + "");
            this.add.setText(this.address + "");
            this.loc.setText(this.location + "");
            this.ph.setText(this.phone + "");
            this.em.setText(this.email + "");
        } catch (Exception e) {
            Toast.makeText(this, "Something Wrong.." + e, 0).show();
        }
    }

    public void onClick(View v) {
        try {
            if (v.getId() == this.f33b.getId()) {
                Toast.makeText(this, "Please Wait....Updating Data...", 1).show();
                this.f35p.setVisibility(0);
                new EditProfileJson(this).execute(new String[]{this.f34n.getText().toString(), this.f32a.getText().toString(), this.add.getText().toString(), this.loc.getText().toString(), this.ph.getText().toString(), this.em.getText().toString(), this.databaseTest.getUsername()});
            }
        } catch (Exception e) {
            Toast.makeText(this, "Something Wrong" + e, 0).show();
        }
    }

    public boolean updateData() {
        try {
            this.databaseTest.updateFromActivity(this.f34n.getText() + "", this.f32a.getText() + "", this.add.getText() + "", this.loc.getText() + "", this.ph.getText() + "", this.em.getText().toString());
            return true;
        } catch (Exception e) {
            Toast.makeText(this, "Something Wrong..." + e, 0).show();
            return false;
        }
    }
}
