package com.example.emergencyhandler;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;

public class excisenum extends AppCompatActivity {
    /* renamed from: c */
    WebView f50c;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_excisenum);
        this.f50c = (WebView) findViewById(C0274R.id.webView2);
        this.f50c.loadUrl("file:///android_asset/s.html");
    }
}
