package com.example.emergencyhandler;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;
import com.google.android.gms.drive.DriveFile;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import org.json.JSONException;
import org.json.JSONObject;

public class reportjson extends AsyncTask<String, Void, String> {
    private Context context;
    String date;
    String des;
    String dis;
    String mun;
    String nam;
    String phn;
    String plc;
    String st;
    String time;
    String type;

    public reportjson(Context context) {
        this.context = context;
    }

    protected void onPreExecute() {
    }

    protected String doInBackground(String... arg0) {
        this.plc = arg0[0];
        this.mun = arg0[1];
        this.dis = arg0[2];
        this.st = arg0[3];
        this.date = arg0[4];
        this.time = arg0[5];
        this.des = arg0[6];
        this.type = arg0[7];
        this.nam = arg0[8];
        this.phn = arg0[9];
        try {
            return new BufferedReader(new InputStreamReader(((HttpURLConnection) new URL("https://codersclub.000webhostapp.com/report.php" + (((((((((("?place=" + URLEncoder.encode(this.plc, "UTF-8")) + "&type=" + URLEncoder.encode(this.type, "UTF-8")) + "&munic=" + URLEncoder.encode(this.mun, "UTF-8")) + "&district=" + URLEncoder.encode(this.dis, "UTF-8")) + "&state=" + URLEncoder.encode(this.st, "UTF-8")) + "&date=" + URLEncoder.encode(this.date, "UTF-8")) + "&time=" + URLEncoder.encode(this.time, "UTF-8")) + "&desc=" + URLEncoder.encode(this.des, "UTF-8")) + "&name=" + URLEncoder.encode(this.nam, "UTF-8")) + "&phone=" + URLEncoder.encode(this.phn, "UTF-8"))).openConnection()).getInputStream())).readLine();
        } catch (Exception e) {
            return new String("Exception: " + e.getMessage());
        }
    }

    protected void onPostExecute(String result) {
        String jsonStr = result;
        if (jsonStr != null) {
            try {
                String query_result = new JSONObject(jsonStr).getString("query_result");
                if (query_result.equals("SUCCESS")) {
                    Toast.makeText(this.context, "Incident Reported...", 0).show();
                    Intent i = new Intent(this.context, DrawerActivity.class);
                    i.addFlags(DriveFile.MODE_READ_ONLY);
                    this.context.startActivity(i);
                    return;
                } else if (query_result.equals("FAILURE")) {
                    Toast.makeText(this.context, "Something Went Wrong....", 0).show();
                    return;
                } else if (query_result.equals("ERROR")) {
                    Toast.makeText(this.context, "Couldn't connect to Remote database...Try Again", 0).show();
                    return;
                } else {
                    return;
                }
            } catch (JSONException e) {
                e.printStackTrace();
                Toast.makeText(this.context, "Bad Internet Connection...Try Again...", 0).show();
                return;
            }
        }
        Toast.makeText(this.context, "Bad Internet Connection...Try Again...", 0).show();
    }
}
