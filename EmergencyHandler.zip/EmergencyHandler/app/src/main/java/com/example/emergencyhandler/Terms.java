package com.example.emergencyhandler;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;

public class Terms extends AppCompatActivity {
    Button agr;
    Button dgr;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_terms_and_conditions);
        this.dgr = (Button) findViewById(C0274R.id.button5);
        this.agr = (Button) findViewById(C0274R.id.button4);
        this.agr.setEnabled(false);
        this.dgr.setEnabled(false);
    }
}
