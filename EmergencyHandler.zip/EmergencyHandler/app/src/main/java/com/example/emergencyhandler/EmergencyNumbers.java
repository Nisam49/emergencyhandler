package com.example.emergencyhandler;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class EmergencyNumbers extends AppCompatActivity implements OnClickListener {
    Button ambulance;
    Button anr;
    Button apc;
    Button child;
    Button crime;
    Button ct;
    Button cybercell;
    Button dad;
    Button dsmh;
    Button elc;
    Button excise;
    Button fah;
    Button fire;
    Button frs;
    Button highwayalert;
    Button highwayhelp;
    Button ina;
    Button kcp;
    Button kseb;
    Button ksrtch;
    Button kwtc;
    Button kwth;
    Button pink;
    Button police;
    Button policehelp;
    Button policemessage;
    Button psc;
    Button ti;
    Button vab;
    Button women;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_emergency_numbers);
        this.police = (Button) findViewById(C0274R.id.policen);
        this.ambulance = (Button) findViewById(C0274R.id.ambn);
        this.fire = (Button) findViewById(C0274R.id.firen);
        this.pink = (Button) findViewById(C0274R.id.pinkn);
        this.women = (Button) findViewById(C0274R.id.womenn);
        this.child = (Button) findViewById(C0274R.id.childn);
        this.excise = (Button) findViewById(C0274R.id.excisen);
        this.highwayalert = (Button) findViewById(C0274R.id.highalertn);
        this.policehelp = (Button) findViewById(C0274R.id.policehelplinen);
        this.policemessage = (Button) findViewById(C0274R.id.policemessagen);
        this.crime = (Button) findViewById(C0274R.id.crimen);
        this.highwayhelp = (Button) findViewById(C0274R.id.policehighn);
        this.ina = (Button) findViewById(C0274R.id.ina);
        this.cybercell = (Button) findViewById(C0274R.id.cybercell);
        this.kwtc = (Button) findViewById(C0274R.id.KWTC);
        this.kwth = (Button) findViewById(C0274R.id.kWTH);
        this.kseb = (Button) findViewById(C0274R.id.KSEB);
        this.fah = (Button) findViewById(C0274R.id.FAH);
        this.elc = (Button) findViewById(C0274R.id.ELC);
        this.anr = (Button) findViewById(C0274R.id.ANR);
        this.dad = (Button) findViewById(C0274R.id.DAD);
        this.dsmh = (Button) findViewById(C0274R.id.DSMH);
        this.ksrtch = (Button) findViewById(C0274R.id.KSRTCH);
        this.frs = (Button) findViewById(C0274R.id.FRS);
        this.vab = (Button) findViewById(C0274R.id.VAB);
        this.apc = (Button) findViewById(C0274R.id.APC);
        this.ct = (Button) findViewById(C0274R.id.CT);
        this.kcp = (Button) findViewById(C0274R.id.KCP);
        this.ti = (Button) findViewById(C0274R.id.TI);
        this.psc = (Button) findViewById(C0274R.id.PSC);
        this.kcp.setOnClickListener(this);
        this.ti.setOnClickListener(this);
        this.psc.setOnClickListener(this);
        this.vab.setOnClickListener(this);
        this.ct.setOnClickListener(this);
        this.apc.setOnClickListener(this);
        this.dad.setOnClickListener(this);
        this.elc.setOnClickListener(this);
        this.anr.setOnClickListener(this);
        this.frs.setOnClickListener(this);
        this.ksrtch.setOnClickListener(this);
        this.dsmh.setOnClickListener(this);
        this.cybercell.setOnClickListener(this);
        this.kwtc.setOnClickListener(this);
        this.kwth.setOnClickListener(this);
        this.fah.setOnClickListener(this);
        this.kseb.setOnClickListener(this);
        this.police.setOnClickListener(this);
        this.ambulance.setOnClickListener(this);
        this.fire.setOnClickListener(this);
        this.pink.setOnClickListener(this);
        this.ina.setOnClickListener(this);
        this.women.setOnClickListener(this);
        this.child.setOnClickListener(this);
        this.excise.setOnClickListener(this);
        this.highwayalert.setOnClickListener(this);
        this.policehelp.setOnClickListener(this);
        this.policemessage.setOnClickListener(this);
        this.crime.setOnClickListener(this);
        this.highwayhelp.setOnClickListener(this);
    }

    public void onClick(View view) {
        try {
            Intent callIntent = new Intent("android.intent.action.CALL");
            if (view.getId() == this.police.getId()) {
                callIntent.setData(Uri.parse("tel:100"));
                startActivity(callIntent);
            } else if (view.getId() == this.ambulance.getId()) {
                callIntent.setData(Uri.parse("tel:108"));
                startActivity(callIntent);
            } else if (view.getId() == this.fire.getId()) {
                callIntent.setData(Uri.parse("tel:101"));
                startActivity(callIntent);
            } else if (view.getId() == this.child.getId()) {
                callIntent.setData(Uri.parse("tel:1098"));
                startActivity(callIntent);
            } else if (view.getId() == this.women.getId()) {
                callIntent.setData(Uri.parse("tel:1091"));
                startActivity(callIntent);
            } else if (view.getId() == this.highwayalert.getId()) {
                callIntent.setData(Uri.parse("tel:9846100100"));
                startActivity(callIntent);
            } else if (view.getId() == this.ina.getId()) {
                callIntent.setData(Uri.parse("tel:9497999900"));
                startActivity(callIntent);
            } else if (view.getId() == this.policehelp.getId()) {
                callIntent.setData(Uri.parse("tel:07413273000"));
                startActivity(callIntent);
            } else if (view.getId() == this.policemessage.getId()) {
                callIntent.setData(Uri.parse("tel:9497900000"));
                startActivity(callIntent);
            } else if (view.getId() == this.highwayhelp.getId()) {
                callIntent.setData(Uri.parse("tel:9846100100"));
                startActivity(callIntent);
            } else if (view.getId() == this.crime.getId()) {
                callIntent.setData(Uri.parse("tel:1090"));
                startActivity(callIntent);
            } else if (view.getId() == this.excise.getId()) {
                startActivity(new Intent(getApplicationContext(), excisenum.class));
            } else if (view.getId() == this.pink.getId()) {
                callIntent.setData(Uri.parse("tel:1515"));
                startActivity(callIntent);
            } else if (view.getId() == this.cybercell.getId()) {
                callIntent.setData(Uri.parse("tel:0471-2449090"));
                startActivity(callIntent);
            } else if (view.getId() == this.kwtc.getId()) {
                callIntent.setData(Uri.parse("tel:155313"));
                startActivity(callIntent);
            } else if (view.getId() == this.kwth.getId()) {
                callIntent.setData(Uri.parse("tel:0471-2322674"));
                startActivity(callIntent);
            } else if (view.getId() == this.kseb.getId()) {
                callIntent.setData(Uri.parse("tel:1912"));
                startActivity(callIntent);
            } else if (view.getId() == this.fah.getId()) {
                callIntent.setData(Uri.parse("tel:1800-425-1125"));
                startActivity(callIntent);
            } else if (view.getId() == this.elc.getId()) {
                callIntent.setData(Uri.parse("tel:1950"));
                startActivity(callIntent);
            } else if (view.getId() == this.anr.getId()) {
                callIntent.setData(Uri.parse("tel:1800 180 5522"));
                startActivity(callIntent);
            } else if (view.getId() == this.dad.getId()) {
                callIntent.setData(Uri.parse("tel:0471-2552056"));
                startActivity(callIntent);
            } else if (view.getId() == this.frs.getId()) {
                callIntent.setData(Uri.parse("tel:0471-211 5054"));
                startActivity(callIntent);
            } else if (view.getId() == this.dsmh.getId()) {
                callIntent.setData(Uri.parse("tel:1070"));
                startActivity(callIntent);
            } else if (view.getId() == this.ksrtch.getId()) {
                callIntent.setData(Uri.parse("tel:9447071021"));
                startActivity(callIntent);
            } else if (view.getId() == this.vab.getId()) {
                callIntent.setData(Uri.parse("tel:8592900900"));
                startActivity(callIntent);
            } else if (view.getId() == this.apc.getId()) {
                callIntent.setData(Uri.parse("tel:0471 2460001"));
                startActivity(callIntent);
            } else if (view.getId() == this.ct.getId()) {
                callIntent.setData(Uri.parse("tel:1800 425 4777"));
                startActivity(callIntent);
            } else if (view.getId() == this.kcp.getId()) {
                callIntent.setData(Uri.parse("tel:1093"));
                startActivity(callIntent);
            } else if (view.getId() == this.ti.getId()) {
                callIntent.setData(Uri.parse("tel:1-800-425-4747"));
                startActivity(callIntent);
            } else if (view.getId() == this.psc.getId()) {
                callIntent.setData(Uri.parse("tel:0471- 2554000"));
                startActivity(callIntent);
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Permission Denied for Calling....", 0).show();
            Toast.makeText(getApplicationContext(), "Modify the permission in App Settings...", 0).show();
        }
    }
}
