package com.example.emergencyhandler;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    /* renamed from: b */
    Button f36b;
    EditText e1;
    EditText e2;
    /* renamed from: p */
    ProgressBar f37p;
    /* renamed from: t */
    TextView f38t;
    DatabaseTest test;

    /* renamed from: coderzclub.doordie.LoginActivity$1 */
    class C02681 implements OnClickListener {
        C02681() {
        }

        public void onClick(View v) {
            try {
                LoginActivity.this.f37p.setVisibility(0);
                String user = LoginActivity.this.e1.getText().toString();
                String pass = LoginActivity.this.e2.getText().toString();
                if (user.isEmpty() || pass.isEmpty()) {
                    LoginActivity.this.f37p.setVisibility(4);
                    Toast.makeText(LoginActivity.this.getApplicationContext(), "Some Fields are Missing...", 0).show();
                    return;
                }
                try {
                    Toast.makeText(LoginActivity.this, "Logging in....Please Wait...", 1).show();
                    new loginjson(LoginActivity.this.getApplicationContext()).execute(new String[]{user, pass});
                } catch (Exception e) {
                    Toast.makeText(LoginActivity.this, e + "", 0).show();
                }
            } catch (Exception e2) {
                LoginActivity.this.f37p.setVisibility(4);
                Toast.makeText(LoginActivity.this.getApplicationContext(), "Something Wrong.. " + e2, 0).show();
            }
        }
    }

    /* renamed from: coderzclub.doordie.LoginActivity$2 */
    class C02692 implements OnClickListener {
        C02692() {
        }

        public void onClick(View v) {
            LoginActivity.this.startActivity(new Intent(LoginActivity.this.getApplicationContext(), RegisterActivity.class));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0274R.layout.activity_login);
        this.test = new DatabaseTest(getApplicationContext());
        this.f36b = (Button) findViewById(C0274R.id.button);
        this.f37p = (ProgressBar) findViewById(C0274R.id.progressBar4);
        this.f38t = (TextView) findViewById(C0274R.id.textView20);
        this.e1 = (EditText) findViewById(C0274R.id.editText);
        this.e2 = (EditText) findViewById(C0274R.id.editText2);
        this.f37p.setVisibility(4);
        this.f36b.setOnClickListener(new C02681());
        this.f38t.setOnClickListener(new C02692());
    }

    public void onRestart() {
        super.onRestart();
        finish();
    }

    public void onBackPressed() {
        moveTaskToBack(true);
        finish();
    }
}
